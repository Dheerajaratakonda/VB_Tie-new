import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, Link,Switch, withRouter} from 'react-router-dom';

class NavBar1 extends React.Component{
	constructor(props){
		super(props);
		this.state={data:this.props.name,noti:"inlineBlock",ur:"none",dr:"none"};
		this.group=this.props.group;
		this.myFunction = this.myFunction.bind(this);
		this.logout = this.logout.bind(this);
		this.duplicate = this.duplicate.bind(this);
		this.broker_vendor = this.broker_vendor.bind(this);
		this.audit = this.audit.bind(this);
		this.unassigned=this.unassigned.bind(this);

	}
	componentWillMount(){
		if (this.group=="admin"){
			this.setState({noti:"inlineBlock",dr:"inlineBlock"});
		}else{
			this.setState({noti:"none",dr:"none"});
		};
		
		if (this.group=="user" || this.group=="admin"){
			this.setState({ur:"inlineBlock"});
		}else{
			this.setState({ur:"none"});
		}
	
	}
		
	myFunction(e){
		var x = document.getElementById("myTopnav");
		console.log("inside func", x);
		if (x.className === "topnav") {
			console.log("inside if");
			x.className += " responsive";
		} else {
			console.log("inside else");
			x.className = "topnav";
		}
	}
	logout(){
		
		this.props.history.push('/logout');
	}
	duplicate(e){
		this.props.history.push({pathname:'/duplicate_report', state:{data: this.state.data,group:this.group}})
	}
	broker_vendor(e){
		this.props.history.push({pathname:'/broker_vendor_report', state:{data: this.state.data,group:this.group}})
		
	}
	unassigned(e){
		this.props.history.push({pathname:'/unassigned_report', state:{data: this.state.data,group:this.group}})
	}
	
	audit(e){
		this.props.history.push({pathname:'/audit_logs', state:{data:this.state.data,group:this.group}})
	}
	
	render(){
		return	(	<div className="topnav" id="myTopnav">
					<a href="#">S<i>y</i>sco | VENDOR-BROKER TIE</a>
  
					<a href="javascript:void(0);" style={{fontSize:"15px"}} className="icon" onClick={this.myFunction}>&#9776;</a>
					<span style={{float:"right"}}>
					<span>
					 <button className="btn btn-default btn-sm btn-link" style={{fontSize:"25px",display:this.state.noti}}>
							<span className="glyphicon glyphicon-bell" style={{color:"white"}}></span>
							<span className="badge badge-notify">3</span>
					</button>
							 
					</span>
						<span className="dropdown">
							<button className="dropbtn"> Reports 
							 <i className="fa fa-caret-down"></i>
							</button>
							<span className="dropdown-content" style={{cursor:"pointer"}}>
							  <a onClick={this.unassigned} style={{display:this.state.ur}}>Unassigned and New Item</a>
							  <a onClick={this.duplicate} style={{display:this.state.dr}}>Duplicate records</a>
							  <a onClick={this.broker_vendor}>Broker-Vendor records</a>
							</span><span className="line">|</span>
						</span>
						
						<a onClick={this.audit} >Audit Logs </a>
						<span className="dropdown" >
						<span className="line">|</span>
						
							<button className="dropbtn"><span className="glyphicon glyphicon-user"></span> {this.state.data}
							 <i className="fa fa-caret-down"></i>
							</button>
							<span className="dropdown-content" style={{cursor:"pointer"}}>
							  <a onClick={this.logout}>Logout</a>
							</span>
						</span> 	
					</span>
				</div>
)
	}
}

export default withRouter(NavBar1);
