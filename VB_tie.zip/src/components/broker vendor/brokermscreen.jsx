import React from 'react';
import FormGroup from 'react-bootstrap/lib/FormGroup';
import Button from 'react-bootstrap/lib/Button';
import Vendor from './vendor.jsx';
import Item from './item.jsx';
import Opco from './opco.jsx';
import Supc from './supc.jsx';
import NavBar1 from '../admin welcome/navbar.jsx';
import AllFilters from './filters.jsx';
class MainScreen2 extends React.Component{
	constructor(props){
		super(props);
		this.state={data: {	
							brokerName:'',
							brokerCode:'',
							brokerNumber:''
					},
					edit:"none",
					viewAll:"block"
					};
		this.name=this.props.location.state.data;
		
		this.group=this.props.location.state.group;
		this.setEmpState = this.setEmpState.bind(this);
	
		this.item=this.item.bind(this);
		this.edit=this.edit.bind(this);
	}
	
    componentWillMount(){
		this.row=this.props.location.state.row;
        if (this.group==="admin"){
			this.state.data={
				brokerCode:this.row.code,
				brokerName:this.row.name,
				brokerNumber:this.row.brokerNumber
			};
			
			this.setState({
				data:this.state.data
			})
			this.setState({edit:"block",viewAll:"none"});
            
			console.log(this.row);
        }
		else if(this.group==="user"){
			
			this.state.data={
				brokerCode:this.props.location.state.brokerCode,
				brokerName:this.props.location.state.brokerName,
				brokerNumber:this.props.location.state.brokerNumber
			};
			
			this.setState({
				data:this.state.data
			})
		}
			
		
    }
	
	setEmpState(e){
			var field = e.target.name;
			var value = e.target.value;
			this.state.data[field] = value;
			this.setState({ data: this.state.data, value: event.target.value });
            this.state = {value: 'coconut'};
    }
	
  	
	item(e){
		this.props.history.push({pathname:'/allitems',state:{data:this.name,group:this.group}});
	}	
		
	enableDesc(){
		this.setState({searchDesc:true});
	}
    
    edit(e){
        this.props.history.push({pathname:"/edit",
                                state:{
                                    data:this.name,
                                    row:this.row,
									group:this.group
                                }})
    }
	render(){
		return 	<div className="container-fluid">
					<NavBar1 name={this.name} group={this.group}/><br/><br/>
					<div className="bms" style={{fontWeight:"bold"}}><span>{this.state.data.brokerCode} </span><span>{this.state.data.brokerName} </span>
                        <a href="#" data-toggle="tooltip" style={{display:this.state.edit}} data-placement="bottom" title="Edit" onClick={this.edit}><i className="fa fa-edit my"></i></a>
							</div>
							<br/><br/>
					<form className="form-horizontal">
					
					
					<div className="row" style={{align:"center"}}>
						<div><AllFilters brokerNumber={this.state.data.brokerNumber}/></div>
					</div>	
					
					<div className="btext"  style={{display:this.state.viewAll}}><a onClick={this.item}>click here to view all items</a></div>
					
			</form>
			<br/><br/><br/>
			</div>
	
}

}
export default MainScreen2;