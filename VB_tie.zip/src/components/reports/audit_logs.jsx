import React from 'react';
import FormGroup from 'react-bootstrap/lib/FormGroup';
import Button from 'react-bootstrap/lib/Button';
import NavBar1 from '../admin welcome/navbar.jsx';

class AuditLogs extends React.Component{
	
	constructor(props){
		super(props)
		this.state={data: {	opcoId:'', 
							itemId:'', 
							vendor:'', 
							brokerName:'',
							brokerCode:'',
							brokerUSerId:'',
							creationDate:'',
							modificationDate:'',
							typeOfAudit:''
						}}
		
		this.name=this.props.location.state.data;
		this.group=this.props.location.state.group;
	}
	setEmpState(e){
               var field = e.target.name;
               var value = e.target.value;
               this.state.data[field] = value;
			   console.log(this.state.data)
			   
               this.setState({ data: this.state.data });
              }
	
	
	render(){
		return 	<div>
						
					<NavBar1 name={this.name} group={this.group}/>
					<br/>
					<div className="class1">
						<div className="row">
							
		
							<form className="form-horizontal col-md-offset-1">
							<br/><br/>
								<FormGroup>
									<div className="col-md-4"><label>Opco Id: </label></div>
									<div className="col-md-6">
										<input className="form-control" type="text" name="opcoId" value={this.state.data.opcoId} onChange={this.setEmpState}/>
									</div>
								</FormGroup>
								<FormGroup>
									<div className="col-md-4"><label>Item Id: </label></div>
									<div className="col-md-6">
										<input className="form-control" type="text" name="itemId" value={this.state.data.itemId} onChange={this.setEmpState}/>
									</div>
								</FormGroup><FormGroup>
									<div className="col-md-4"><label>Vendor: </label></div>
									<div className="col-md-6">
										<input className="form-control" type="text" name="vendor" value={this.state.data.vendor} onChange={this.setEmpState}/>
									</div>
								</FormGroup><FormGroup>
									<div className="col-md-4"><label>Broker Name: </label></div>
									<div className="col-md-6">
										<input className="form-control" type="text" name="brokerName" value={this.state.data.brokerName} onChange={this.setEmpState}/>
						 			</div>
								</FormGroup>
								<FormGroup>
									<div className="col-md-4"><label>Broker Code: </label></div>
									<div className="col-md-6">
										<input className="form-control" type="number" name="brokerCode" value={this.state.data.brokerCode} onChange={this.setEmpState}/>
						 			</div>
								</FormGroup>
								<FormGroup>
									<div className="col-md-4"><label>Broker User Id: </label></div>
									<div className="col-md-6">
										<input className="form-control" type="text" name="brokerUSerId" value={this.state.data.brokerUSerId} onChange={this.setEmpState}/>
						 			</div>
								</FormGroup>
								<FormGroup>
									<div className="col-md-4"><label>Creation Date: </label></div>
									<div className="col-md-6">
										<input className="form-control" type="date" name="creationDate" value={this.state.data.creationDate} onChange={this.setEmpState}/>
						 			</div>
								</FormGroup>
								<FormGroup>
									<div className="col-md-4"><label>Modification Date: </label></div>
									
									<div className="col-md-6">
										<input className="form-control" type="date" name="modificationDate" value={this.state.data.modificationDate} onChange={this.setEmpState}/>
						 			</div>
								</FormGroup>
					
								<FormGroup>
									<div className="col-md-4"><label>Type of Audits: </label></div>
									<div className="col-md-6">
										<input className="form-control" type="text" name="typeOfAudit" value={this.state.data.typeOfAudit} onChange={this.setEmpState}/>
						 			</div>
								</FormGroup>
							</form>
							
						</div>
						
					</div>
				</div>
	}
}
export default AuditLogs;